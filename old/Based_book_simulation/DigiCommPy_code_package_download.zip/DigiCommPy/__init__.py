"""
Package loader: DigiCommPy.__init__.py
===============================================================================
DigiCommPy package
"""